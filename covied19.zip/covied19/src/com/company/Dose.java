package com.company;

public class Dose {
    private int number;
    private String date;
    private String patientName;
    private String medicalPName;

    public Dose() {
    }

    public Dose(int number, String date, String patientName, String medicalPName) {
        this.number = number;
        this.date = date;
        this.patientName = patientName;
        this.medicalPName = medicalPName;
    }

    public int getNumber() {
        return number;
    }

    public String getDate() {
        return date;
    }

    public String getPatientName() {
        return patientName;
    }

    public String getMedicalPName() {
        return medicalPName;
    }

    public void setNumber(int number) {
        this.number = number;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public void setPatientName(String patientName) {
        this.patientName = patientName;
    }

    public void setMedicalPName(String medicalPName) {
        this.medicalPName = medicalPName;
    }


    @Override
    public String toString() {
        return "Dose{" +
                "number=" + number +
                ", date:" + date +
                ", patientName is " + patientName +
                ", medicalPName is " + medicalPName +
                '}';
    }
}
