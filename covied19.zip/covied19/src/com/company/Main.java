package com.company;

import java.util.ArrayList;
import java.util.Scanner;

public class Main {

    public static CircularLinkedList<Dose> doses=new CircularLinkedList<Dose>();
    private static int numberOfDose=100;

    private static void addDose(){
        Scanner scanner=new Scanner(System.in);
        System.out.println("Please enter the dose's number: ");
        int n=scanner.nextInt();
        System.out.println("Please enter the patientName: ");
        String pName=scanner.next();
        System.out.println("Please enter the medicalPName: ");
        String MName=scanner.next();
        System.out.println("Please enter the date(yyyy/mm/dd): ");
        String da=scanner.next();
        Dose dose=new Dose(n,da,pName,MName);
        doses.addFirst(dose);
    }

    private static int total2ndDose(){
        Dose d;
        CircularLinkedList.Node current	=doses.head;
        int	count	=	0;
        if (current==null){
            return 0;
        }
        do	{
            d=(Dose)current.getValue();
            if(d.getNumber()==2){
                count++;
            }
            current	=	current.getNext();
        }while	(current	!=	doses.head);

        return count;
    }

    private static int total1stDose(){
        Dose d;
        CircularLinkedList.Node current	=doses.head;
        int	count	=	0;
        if (current==null){
            return 0;
        }
        do	{
            d=(Dose)current.getValue();
            if(d.getNumber()==1){
                count++;
            }
            current	=	current.getNext();
        }while	(current	!=	doses.head);

        return count;
    }

    private static void	display()	{
        if	(doses.head==null)	{
            System.out.println("The list is empty ...	");
            return;
        }
        System.out.println("\n\nDisplay	List:	");
        CircularLinkedList.Node current	=	doses.head;

        do	{
            System.out.println(current.getValue());
            current	=	current.getNext();
        }while	(current	!=	doses.head);

        System.out.println("");
    }

    private static int doeNumber(){

        return numberOfDose-doses.size;
    }

    private static int dayTotal(String day){
        Dose d;
        CircularLinkedList.Node current	=doses.head;
        int	count	=	0;
        if (current==null){
            return 0;
        }
        do	{
            d=(Dose)current.getValue();
            if(d.getDate().equals(day)){
                count++;
            }
            current	=	current.getNext();
        }while	(current	!=	doses.head);

        return count;
    }

    private static int total(){
        return doses.size;
    }

    private static void deleteDoses(){

         while(doses.head!=null){
             doses.removeFirst();
         }

    }

    private static void newDoses(){
        Scanner scanner=new Scanner(System.in);
        System.out.print("Enter the number of Doses you want to add: ");
        int x=scanner.nextInt();
        numberOfDose=numberOfDose+x;
    }

    public static void main(String[] args) {
        Scanner scanner=new Scanner(System.in);
        int x=0;
        do{
            System.out.println("###################################################"+
                            "\nWelocme into Covid-19 vacancies warehouse system: \n\n"+
                    "1...Display all the information about doses \n"+
                    "2...the total number of doses used \n"+
                    "3...the total number of doses used in one day \n"+
                    "4...the total number of doses remaining \n"+
                            "5...the total number of first doses of vaccine \n" +
                            "6...the total number of second doses of vaccine \n"+
                    "7...Add new dose \n"+
                    "8...Add doses to the store\n"+
                    "9...Delete all doses \n"+
                    "10..Exit\n\n"
                    );
            System.out.print("Enter your choice please: ");
            x=scanner.nextInt();
            switch (x){
                case 1:
                    display();
                    break;
                case 2:
                    System.out .println("\nThe total number of doses until today is:"+total());
                    break;
                case 3:
                    System.out.print("\nEnter the day you want:(yyyy/mm/dd) ");
                    String s=scanner.next();
                    System.out.println("The total number of doses used in "+s+" is: "+dayTotal(s));
                    break;
                case 4:
                    System.out.println("\nThe number of doses remaining is: "+doeNumber());
                    break;
                case 5:
                    System.out.println("\nThe number of first doses of vaccine is: "+total1stDose());
                    break;
                case 6:
                    System.out.println("\nThe number of second doses of vaccine is: "+total2ndDose());
                    break;
                case 7:
                    addDose();
                    break;
                case 8:
                    newDoses();
                    break;
                case 9:
                    deleteDoses();
                    System.out.println("\nAll doses deleted...");
                    break;
                case 10:
                    break;
            }
        }while (x!=10);


    }
}


/*

 //      display;
 //      total;
 //      dayTotal;
 //      doeNumber;
 //      total2ndDose;
 //      total1stDose;
 //      addDose;
       newDose;
  //     deleteDoses;


 */