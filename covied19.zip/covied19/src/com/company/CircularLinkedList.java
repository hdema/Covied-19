package com.company;
public	class	CircularLinkedList<E>	{

    class	Node<E>	{
        private	E	value;
        private	Node	next;
        Node(E	value,	Node	next)	{
            this.value	=	value;
            this.next	=	next;
        }
        E	getValue()	{
            return	value;
        }
        Node	getNext()	{
            return	next;
        }
        void	setValue(E	value)	{
            this.value	=	value;
        }
        void	setNext(Node	next)	{
            this.next	=	next;
        }
    }

    Node<E>	head	=	null;
    Node<E>	tail	=	null;
    int	size	=	0;
    CircularLinkedList()	{}
    int	getSize()	{
        return	size;
    }
    E	first()	{
        return	head.getValue();
    }
    E	last()	{
        return	tail.getValue();
    }
    boolean	isEmpty()	{
        if	(size	==	0)	{
            return	true;
        }	else	{
            return	false;
        }
    }




    //All	linkedList	methods	here;;;
    void	display()	{
        if	(isEmpty())	{
            System.out.println("Empty	List..	");
            return;
        }
        System.out.println("Display	List:	");
        Node<E>	current	=	head;
        int	count	=	1;


        do	{
            System.out.print("\tNode	"	+	count	+	"	:"	+	current.getValue());
            current	=	current.getNext();
            count++;
        }while	(current	!=	head);

        System.out.println("");
    }


    void	findNode(E	key)	{

        if	(isEmpty())	{
            System.out.println("Empty	List..	");
            return;
        }

        Node<E>	current	=	head;
        int	counter	=	1;
        boolean	flag=false;

        do	{
            if	(current.getValue()	==	key)	{

                flag=true;
                break;
            }
            counter++;
            current	=	current.getNext();
        }while	(current	!=	head);

        if(flag)
            System.out.println("Found	in	position#	"	+	counter);
        else
            System.out.println("Value	not	found	"	);
    }
    void	removeFirst()	{

        if	(isEmpty())	{
            System.out.println("Empty	List..	");
            return;
        }

        head	=	head.getNext();
        tail.next=head;
        size--;
//if	this	was	the	last	and	only	node..	fix	tail
        if	(size	==	0)	{
            head=null;
            tail	=	null;
        }
    }
    void	addFirst(E	value)	{
        Node<E>	newNode	=	new	Node<E>(value,	head);
        head	=	newNode;
        if	(size	==	0)	{
            tail	=	head;
        }
        tail.next=head;
        size++;
    }
    void	addLast(E	value)	{
        Node<E>	newNode	=	new	Node<E>(value,	null);
        if	(size	==	0)	{
            head=newNode;
            tail=head;
        }
        else
        {
            tail.next	=	newNode;
            tail	=	newNode;
        }
        tail.next	=	head;
        size++;
    }

    void	removeNode(E	key)	{	//delete	a	node	at	any	position
        if	(isEmpty())	{
            System.out.println("\nEmpty	list...");
            return;
        }//end	if

        if(head.getValue()==key)
        {
            removeFirst();
            return;
        }

        Node<E>	current	=	head;
        Node<E>	prev	=	head;

        while	(current.getValue()	!=	key)	{
            if	(current.next	==	head)	{
                System.out.println("\nNot	found...");
                return;
            }
            prev	=	current;
            current	=	current.next;
        }//end	loop

        prev.next	=	current.next;
        size--;

    }//end	removeNode
    public	void	addAtPoistion(E	e,	int	position)	{
//check	if	the	position	is	correct	(from	1	to	size)
        if	(position	<	1	||	position	>	size)	{
            System.out.println("Invalid	Position");
            return;
        }
//Check	if	the	position	1	(first	node)
        if	(position	==	1)	{
            addFirst(e);
            return;
        }
//any	other	location
        Node<E>	newNode	=	new	Node<E>(e,	null);
        Node<E>	current	=	head;
        int	count	=	1;
        while	(count	<	position	- 1)	{
            current	=	current.getNext();
            count++;
        }
//found..
        newNode.setNext(current.getNext());
        current.setNext(newNode);
        size++;
    }

    public	void	RemoveAtPoistion(E	e,	int	position)	{
//check	if	the	position	is	correct	(from	1	to	size)
        if	(position	<	1	||	position	>	size)	{
            System.out.println("Invalid	Position");
            return;
        }
//Check	if	the	position	1	(first	node)
        if	(position	==	1)	{
            removeFirst();
            return;
        }
//any	other	location
        Node<E>	current	=	head;
        Node<E>	prev	=	head;

        int	count	=	1;
        while	(count	<	position)	{
            prev=current;
            current	=	current.getNext();
            count++;
        }
        prev.next	=	current.next;
        size--;
    }

    public	void	rotate()	{
        if	(!isEmpty())	{
            tail=head;
            head	=	head.getNext();
        }
    }
}
